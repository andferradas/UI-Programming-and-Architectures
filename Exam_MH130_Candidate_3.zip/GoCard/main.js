// For the timer of the splash screen
window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    startApp();
  }, 1500);
});

