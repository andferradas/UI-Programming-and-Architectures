export class Package {
    constructor(id, nameCollection, image, cards = []) {
        this.id = id;
        this.nameCollection = nameCollection;
        this.image = image;
        this.cards = cards;
    }
}